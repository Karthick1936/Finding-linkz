chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Received links in background script:", message.links);
});