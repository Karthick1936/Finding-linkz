chrome.runtime.onMessage.addListener((msg, sender, response) => {
  console.log("Message from popup:", msg);
});