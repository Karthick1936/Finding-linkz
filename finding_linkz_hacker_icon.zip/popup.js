document.getElementById("find-links").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: extractHiddenLinks,
  }, (results) => {
    if (chrome.runtime.lastError) {
      document.getElementById("link-list").textContent = "Error: " + chrome.runtime.lastError.message;
    } else {
      const result = results[0].result;
      document.getElementById("link-list").innerHTML = result.length
        ? result.map(link => `<a href="${link}" target="_blank">${link}</a>`).join("<br>")
        : "No hidden links found.";
    }
  });
});

function extractHiddenLinks() {
  const hiddenLinks = [...document.querySelectorAll("a")].filter(a => {
    const style = window.getComputedStyle(a);
    return (
      style.display === "none" ||
      style.visibility === "hidden" ||
      parseFloat(style.opacity) === 0
    );
  }).map(a => a.href);
  return hiddenLinks;
}